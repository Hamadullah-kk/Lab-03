import java.util.Scanner;
class task04{
	public static void main(String[] arge){

		int[] array = new int[10];
		int index = 0, sum = 0, num = 1;
		do {
		  array[index] = num*num;
          num++;
        index++;
		}while(index < 10);

        int index2 = 0;
		while(index2 < 10){
			if(array[index2] == 81) {
			  break;	
			}
			if(array[index2] % 2 != 0){
             sum += array[index2];
			}
		index2++;	
		}
			System.out.print("Sum of all odd number in this array: "+sum);
	}
}