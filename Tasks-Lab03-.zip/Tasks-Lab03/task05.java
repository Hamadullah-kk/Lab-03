import java.util.Scanner;
class task05{
	public static void main(String[] args){
	Scanner input = new Scanner(System.in);
		boolean[][] seat = {{true,true,true,false},
	                        {false,false,true,false},
	                        {true,true,false,false},
	                        {false,false,false,false}};
      
       int choice ;
       int rows;
       int column;  
	    do{
         System.out.println("\ni. Display available seats: 1");
         System.out.println("ii. Reserve a seat: 2");
         System.out.println("iii. Exit: 3");
         System.out.print("iv. Enter your choice:");
        choice = input.nextInt();
        switch(choice){

        case 1:
        	System.out.println("\nTheater seating (False = Available seats and True = Unavailable seats.\n ");
         for(int i = 0; i < seat.length; i++){
         	for(int j = 0; j < seat.length; j++){
         	 System.out.print(i+""+j+" "+seat[i][j]+" : ");
         	}
         	System.out.println();
         	 }
         	 break;

        case 2:
          System.out.println("\nEnter Rows no. and Column no. of seata: ");
           rows = input.nextInt();
           column = input.nextInt();
           if(seat[rows][column]==true){
           	System.out.println("The seat is already reserve.");
           }else{
           	seat[rows][column]=true;
            System.out.println("Reserve the seat.");
             }
            break;

        default :
        	System.out.print("Invalid choice : ");
             }

	    }while(choice!=3);                    
	}    
}