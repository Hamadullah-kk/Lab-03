import java.util.Scanner;
class task01{
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the rang of prime number that you want. ");
		System.out.print("Enter the number where prime nuber start :  ");
		int from = input.nextInt();
		System.out.print("Enter the number where the prime number end : ");
		int to = input.nextInt();

		for(int i = from; i <= to; i++){
			boolean isPrime = true;
			for(int j = 2; j<i; j++){
				if(i%j==0){
					isPrime = false;
					break; 
				}
			}
			if(isPrime){
				System.out.println(i);
			}
		}
    	

	}
}