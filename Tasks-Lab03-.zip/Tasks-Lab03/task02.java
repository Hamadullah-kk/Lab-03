import java.util.Scanner;
class task02{
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		System.out.print("Enter any text or word : ");
		String text = input.nextLine();
    String text2 = "";
		for(int i = 0; i<text.length(); i++){
			System.out.println(text.charAt(i));
		}
		
		System.out.println("");
		for(int j = text.length()-1; j>=0; j--){
			System.out.println(text.charAt(j));
			text2 = text2+text.charAt(j);
		}
		if(text2.equals(text)){
			System.out.println("The word "+text+" is palindrome.");
		}else{
			System.out.println("The word "+text+" is not palindrome.");
		}

	}
} 