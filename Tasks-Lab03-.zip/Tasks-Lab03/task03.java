import java.util.Scanner;
class task03{
	public static void main(String[] args){
		int[][] matrix = {{12,13,15,16},
	                      {11,110,121,17},
	                      {17,18,100,21}};
	    int sum = 0; //Creat integer sum for add even numbers.                 
   
         //Print the given array.
	 for(int i = 0; i<matrix.length; i++){
	     	for(int j = 0; j<4; j++){
	     		System.out.print(matrix[i][j]+" ");
	     	}
                System.out.println();   }

        //finding even number in 2D-Array and restore in same index.
	     for(int i = 0; i<matrix.length; i++){
	     	for(int j = 0; j<4; j++){
	     		if(matrix[i][j]%2==0){
	     	matrix[i][j] = matrix[i][j]/2;	}
	     	}

             System.out.print("");   }

   
        //find odd number in 2D-Array.
        System.out.println("These are odd number in the matrix :");
	     for(int i = 0; i<matrix.length; i++){
	     	for(int j = 0; j<4; j++){
	     		if(matrix[i][j]%2!=0){
	     			System.out.print(matrix[i][j]+" ");  }
	          }
               }

         
         //This is the sum of all even number;
         for(int i = 0; i<matrix.length; i++){
	     	for(int j = 0; j<4; j++){
	     		if(matrix[i][j]%2==0){
	     		sum += matrix[i][j];
	     		}
	     	}   } 
          System.out.println("\nThis is the sum of all even number : "+sum);
	}
}